import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup} from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import {filter, map} from 'rxjs/operators';
import {Observable, of} from 'rxjs';

export interface AutoCompleteModel {
   value: any;
   display: string;
}

@Component({
  selector: 'app-tag-input',
  templateUrl: './tag-input.component.html',
  styleUrls: ['./tag-input.component.css']
})
export class TagInputComponent implements OnInit {

    form: FormGroup;

    constructor() { 
     this.form = new FormBuilder().group({
            chips: [['chip'], []]
        });
    }

    ngOnInit() {
    }       

    private startsWithAt(control: FormControl) {
        if (control.value.charAt(0) !== '@') {
            return {
                'startsWithAt@': true
            };
        }

        return null;
    }
    
    public validators = [this.startsWithAt];

}