import { Component, OnInit } from '@angular/core';
declare var jquery: any;
declare var $: any;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    InputTagObject = [];

    public ngOnInit() {
    }

    public TagdivFocus() {        
        var divobj = $(".tagify__input");
        divobj.html(divobj.text());

    }

    public formatTag() {

        var that = this;
        that.InputTagObject = [];

        var divobj = $(".tagify__input");
        //$("#divReadable").html("");        

        var text = divobj.text();
        divobj.html("");

        if (text) {

            var arrText = text.split(' ');
            var IsFirstText = true;
            arrText.forEach(function (tag) {
                if (tag) {

                    var ObjectText = $.parseHTML(tag);
                    that.InputTagObject.push(tag);

                    var first2Char = '';
                    var last2Char = '';
                    if (tag.length >= 4) {
                        first2Char = tag.substr(0, 2);
                        last2Char = tag.slice(-2);
                    }
                    if (first2Char == '@@' && last2Char == "$$") {
                        console.log("Create tag for text");
                        var tagElm = that.createTagElem(tag);

                        if (IsFirstText) {
                            //$("#divReadable").html(tagElm[0].outerHTML);
                            divobj.html(tagElm[0].outerHTML);
                        }
                        else {
                            //$("#divReadable").html($("#divReadable").html() + tagElm[0].outerHTML);
                            divobj.html(divobj.html() + ' ' + tagElm[0].outerHTML);
                        }
                    }
                    else {
                        if (IsFirstText) {
                            //$("#divReadable").html(tag);
                            divobj.html(tag);
                        }
                        else {
                            //$("#divReadable").html($("#divReadable").html() + ' ' + tag);
                            divobj.html(divobj.html() + ' ' + tag);
                        }
                    }
                }

                IsFirstText = false;
            })

            console.log(that.InputTagObject);
        }
        return true;

    }

    createTagElem(tagData) {

        //debugger;
        var tagElm,
            v = this.escapeHtml(tagData),
            template = "<tag title='" + v + "' contenteditable='false'>\n <x title=''></x><div><span>" + v + "</span></div>\n </tag>";

        template = this.minify(template);
        tagElm = $.parseHTML(template);

        return tagElm;
    }

    escapeHtml(s) {
        var text = document.createTextNode(s),
            p = document.createElement('p');
        p.appendChild(text);
        return p.innerHTML;
    }

    minify(html) {
        return html.replace(new RegExp("\>[\r\n ]+\<", "g"), "><");
    }
}
